package acccount;

public class SavingsAccount extends Accountt {

	static double minBalance;
	static float roi;

	static {
		minBalance = 10000;
		roi = 3;
	}

	public SavingsAccount(String accountNumber, String accountHolderName, double balance, String accountType) {
		super(accountNumber, accountHolderName, balance, accountType);
	}

	@Override
	public double interestRate() {
		double interest = this.balance * (roi / 100);
		return interest;
	}

	@Override
	public void deposit(double amount) {
		super.deposit(amount);
	}

	@Override
	public void withdraw(double amount) {
		if (balance - amount >= minBalance) {
			super.withdraw(amount);
		} else {
			System.out.println("\n Minimum balance we cannot withdraw '" + amount + "' amount :( ");
		}
	}

}

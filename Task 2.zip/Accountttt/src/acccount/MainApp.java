package acccount;

import java.util.Scanner;

public class MainApp {

	public static Accountt[] accounts = new Accountt[100];
	public static EndOfDayReport[] endOfDayReports = new EndOfDayReport[100];
	public static int numOfAccounts = 0;
	public static int numOfReports = 0;

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		boolean continueProgram = true;

		while (continueProgram) {
			System.out.println("\n+-------------------------------------------+");
			System.out.println("|            WELCOME TO PUNE BANK!          |");
			System.out.println("+-------------------------------------------+");
			System.out.println("Please choose an option:");
			System.out.println("\n+-------------------------------------------+");
			System.out.println("|	1. Open a new account               |");
			System.out.println("|	2. Close a related account          |");
			System.out.println("|	3. Deposit money                    |");
			System.out.println("|	4. Withdraw money                   |");
			System.out.println("|	5. Check balance                    |");
			System.out.println("|	6. Generate report                  |");
			System.out.println("|	7. Calculate interest               |");
			System.out.println("|	8. Activate account                 |");
			System.out.println("|	9. Exit                             |");
			System.out.println("+-------------------------------------------+\n");
			System.out.print("Enter your choice: ");
			int choice = scanner.nextInt();
			scanner.nextLine();

			switch (choice) {
			case 1:
				openAccount(scanner);
				break;
			case 2:
				closeAccount(scanner);
				break;
			case 3:
				depositMoney(scanner);
				break;
			case 4:
				withdrawMoney(scanner);
				break;
			case 5:
				checkBalance(scanner);
				break;
			case 6:
				generateReport(scanner);
				break;
			case 7:
				calculateInterest(scanner);
				break;
//                case 8:
//                    activateAccount(scanner);
//                    break;
			case 9:
				continueProgram = false;
				System.out.println("Program terminated.");
				break;
			default:
				System.out.println("Invalid choice!");
			}
		}

		scanner.close();
	}

	public static void openAccount(Scanner scanner) {
		System.out.println("Please choose the account type to open:");
		System.out.println("1. Savings Account");
		System.out.println("2. Salary Account");
		System.out.println("3. Current Account");
		System.out.println("4. Loan Account");
		int accountChoice = scanner.nextInt();
		scanner.nextLine();

		System.out.print("Enter account holder name: ");
		String accountHolderName = scanner.nextLine();
		System.out.print("Enter initial balance: ");
		double balance = scanner.nextDouble();
		scanner.nextLine();

		switch (accountChoice) {
		case 1:
			accounts[numOfAccounts++] = new SavingsAccount(generateAccountNumber(), accountHolderName, balance,
					"Savings Account");
			System.out.println("Savings account opened successfully... Account number: "
					+ accounts[numOfAccounts - 1].getAccountNumber());
			break;
		case 2:
			accounts[numOfAccounts++] = new SalaryAccount(generateAccountNumber(), accountHolderName, balance,
					"Salary Account");
			System.out.println("Salary account opened successfully... Account number: "
					+ accounts[numOfAccounts - 1].getAccountNumber());
			break;
		case 3:
			System.out.print("Enter overdraft limit: ");
			double overdraftLimit = scanner.nextDouble();
			scanner.nextLine();
			accounts[numOfAccounts++] = new CurrentAccount(generateAccountNumber(), accountHolderName, balance,
					"Current Account", overdraftLimit);
			System.out.println("Current account opened successfully... Account number: "
					+ accounts[numOfAccounts - 1].getAccountNumber());
			break;
		case 4:
			System.out.print("Enter loan amount: ");
			double loanAmount = scanner.nextDouble();
			scanner.nextLine();
			System.out.print("Enter interest rate: ");
			float interestRate = scanner.nextFloat();
			scanner.nextLine();
			accounts[numOfAccounts++] = new LoanAccount(generateAccountNumber(), accountHolderName, balance,
					"Loan Account", loanAmount, interestRate);
			System.out.println("Loan account opened successfully... Account number: "
					+ accounts[numOfAccounts - 1].getAccountNumber());
			break;
		default:
			System.out.println("Invalid account choice!");
		}
	}

	public static String generateAccountNumber() {
		// Generate account number logic here, for simplicity, let's return a dummy
		// value
		return "ACC" + (int) (Math.random() * 1000);
	}

	public static void closeAccount(Scanner scanner) {
		System.out.print("Enter account number to close: ");
		String accountNumber = scanner.nextLine();

		boolean found = false;
		for (int i = 0; i < numOfAccounts; i++) {
			if (accounts[i].getAccountNumber().equals(accountNumber)) {
				accounts[i] = null;
				found = true;
				System.out.println("Account closed successfully.");
				break;
			}
		}

		if (!found) {
			System.out.println("Account not found.");
		}
	}

	public static void depositMoney(Scanner scanner) {
		System.out.print("Enter account number to deposit money: ");
		String accountNumber = scanner.nextLine();

		System.out.print("Enter amount to deposit: ");
		double depositAmount = scanner.nextDouble();
		scanner.nextLine();

		boolean found = false;
		for (int i = 0; i < numOfAccounts; i++) {
			if (accounts[i].getAccountNumber().equals(accountNumber)) {
				accounts[i].deposit(depositAmount);
				endOfDayReports[numOfReports++] = new EndOfDayReport(accountNumber, accounts[i].getAccountHolderName(),
						depositAmount, "Money deposited","Successful");
				found = true;
				break;
			}
		}

		if (!found) {
			System.out.println("Account not found.");
		}
	}

	public static void withdrawMoney(Scanner scanner) {
		System.out.print("Enter account number to withdraw money: ");
		String accountNumber = scanner.nextLine();

		System.out.print("Enter amount to withdraw: ");
		double withdrawAmount = scanner.nextDouble();
		scanner.nextLine();

		boolean found = false;
		for (int i = 0; i < numOfAccounts; i++) {
			if (accounts[i].getAccountNumber().equals(accountNumber)) {
				accounts[i].withdraw(withdrawAmount);
				endOfDayReports[numOfReports++] = new EndOfDayReport(accountNumber, accounts[i].getAccountHolderName(),
						withdrawAmount, "Money withdrawn","Successful");
				found = true;
				break;
			}
		}

		if (!found) {
			System.out.println("Account not found.");
		}
	}

	public static void checkBalance(Scanner scanner) {
		System.out.print("Enter account number to check balance: ");
		String accountNumber = scanner.nextLine();

		boolean found = false;
		for (int i = 0; i < numOfAccounts; i++) {
			if (accounts[i].getAccountNumber().equals(accountNumber)) {
				System.out.println("Balance: " + accounts[i].getBalance());
				found = true;
				break;
			}
		}

		if (!found) {
			System.out.println("Account not found.");
		}
	}

	public static void generateReport(Scanner scanner) {
		System.out.print("Enter username: ");
		String username = scanner.nextLine();
		System.out.print("Enter password: ");
		String password = scanner.nextLine();

		// Hardcoded username and password.
		if (username.equals("sahil") && password.equals("1234")) {
			System.out.println("Transaction Details:");
			System.out.println("+-----------------------+-------------------+-------------------+-------------------+-------------------+");
	        System.out.println("|     Account Number    |   Account Holder  |     Balance       |      Activity     |      Status       |");
	        System.out.println("+-----------------------+-------------------+-------------------+-------------------+-------------------+");
			for (int i = 0; i < numOfReports; i++) {
				endOfDayReports[i].display();
			}
		} else {
			System.out.println("Invalid credentials.");
		}
	}

	public static void calculateInterest(Scanner scanner) {
		System.out.print("Enter account number to calculate interest: ");
		String accountNumber = scanner.nextLine();

		boolean found = false;
		for (int i = 0; i < numOfAccounts; i++) {
			if (accounts[i].getAccountNumber().equals(accountNumber)) {
				double interest = accounts[i].interestRate();
				System.out.println("Interest: " + interest);
				System.out.println("Balance after interest: " + accounts[i].getBalance());
				found = true;
				break;
			}
		}

		if (!found) {
			System.out.println("Account not found.");
		}
	}

//    public static void activateAccount(Scanner scanner) {
//        System.out.print("Enter account number to activate: ");
//        String accountNumber = scanner.nextLine();
//
//        boolean found = false;
//        for (int i = 0; i < numOfAccounts; i++) {
//            if (accounts[i].getAccountNumber().equals(accountNumber)) {
//                if (accounts[i] instanceof SalaryAccount) {
//                    ((SalaryAccount) accounts[i]).setLastTransactionDate(LocalDate.now());
//                    System.out.println("Account activated successfully.");
//                    found = true;
//                    break;
//                } else {
//                    System.out.println("Account is not eligible for activation.");
//                    found = true;
//                    break;
//                }
//            }
//        }
//
//        if (!found) {
//            System.out.println("Account not found.");
//        }
//    }
}

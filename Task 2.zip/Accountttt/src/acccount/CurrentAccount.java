package acccount;

public class CurrentAccount extends Accountt {
	public double overDraftLimit;

	public CurrentAccount(String accountNumber, String accountHolderName, double balance, String accountType,
			double overDraftLimit) {
		super(accountNumber, accountHolderName, balance, accountType);
		this.overDraftLimit = overDraftLimit;
	}

	@Override
	public void deposit(double amount) {
		super.deposit(amount);
	}

	@Override
	public void withdraw(double amount) {
		if (balance + overDraftLimit >= amount) {
			super.withdraw(amount);
		} else {
			System.out.println("Exceeds overdraft limit");
		}
	}

	@Override
	public double interestRate() {

		return 0; // Current accounts don't have interest.
	}

}

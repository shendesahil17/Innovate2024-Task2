package acccount;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class SalaryAccount extends SavingsAccount {

	LocalDate lastTransactionDate;
	public boolean checkAccountStatus;

	public SalaryAccount(String accountNumber, String accountHolderName, double balance, String accountType) {
		super(accountNumber, accountHolderName, balance, accountType);
		checkAccountStatus = true;
		this.lastTransactionDate = LocalDate.of(2008, 4, 4);
	}

///////////////////////////////////////////////////////////////////////////////////

	public boolean isFrozen() {

		long diff = ChronoUnit.DAYS.between(lastTransactionDate, LocalDate.now());
		if (diff <= 60) {
			System.out.println("diff is : " + diff);
			return false;
		} else {
			return true;
		}
	}

	public LocalDate getLastTransactionDate() {
		return lastTransactionDate;
	}

	public void setLastTransactionDate(LocalDate lastTransactionDate) {
		this.lastTransactionDate = lastTransactionDate;
	}

///////////////////////////////////////////////////////////////////////////////////

	@Override
	public void deposit(double amount) {

		super.deposit(amount);
		// this.lastTransactionDate = new Date();

	}

	@Override
	public void withdraw(double amount) {

		super.withdraw(amount);
	}

	@Override
	public double interestRate() {

		if (this.isFrozen()) {
			System.out.println("\n Oops...No activity since last 2 months. Your account got frozen\n");
			return 0;
		} else {
			double intrest = this.balance * (roi / 100);
			System.out.println("Your interest is : " + intrest);
			return intrest;
		}
	}

}

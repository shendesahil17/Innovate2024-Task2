package acccount;

public abstract class Accountt {
	public String accountNumber;
	public String accountHolderName;
	public double balance;
	public String accountType;

	public Accountt() {
		// This is Default Constructor of Account Class.
	}

	public Accountt(String accountNumber, String accountHolderName, double balance, String accTyp) {
		super();
		this.accountNumber = accountNumber;
		this.accountHolderName = accountHolderName;
		this.balance = balance;
		this.accountType = accTyp;
	}

	// setters & getters

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	// Abstract and instance methods.

	public void deposit(double amount) {
		if (amount > 0) {
			balance += amount;
			System.out.println("\n Deposited " + amount + " to " + getAccountType() + " account " + accountNumber);
		} else {
			System.out.println("\n Invalid deposit amount");
		}
	}
	
	
//	public void deposit(double amount) throws InvalidDepositException {
//	    if (amount > 0) {
//	        balance += amount;
//	        System.out.println("\n Deposited " + amount + " to "+ getAccountType() +" account " + accountNumber);
//	    } else {
//	        throw new InvalidDepositException("Invalid deposit amount");
//	    }
//	}

	
	

	public void withdraw(double amount) {
		if (balance >= amount) {
			balance -= amount;
		} else {
			System.out.println("Insufficient funds");
		}
	}
	
	
	
	
	
//	public void withdraw(double amount) throws InsufficientFundsException {
//	    if (balance >= amount) {
//	        balance -= amount;
//	    } else {
//	        throw new InsufficientFundsException("Insufficient funds");
//	    }
//	}

	
	
	
	
	
	

	public abstract double interestRate();

	public void display() {
		System.out.println("Account Type : " + getAccountType());
		System.out.println("Account Number : " + accountNumber);
		System.out.println("Account Holder Name : " + accountHolderName);
		System.out.println("Balance : " + balance);
		System.out.println("\n-----------------------------------------\n");
	}

//	@Override
//	public String toString() {
//		return "Accountt [accountNumber=" + accountNumber + ", accountHolderName=" + accountHolderName + ", balance="
//				+ balance + ", accountType=" + accountType + "]";
//	}
}

package acccount;

public class EndOfDayReport {
	public String accountNumber;
	public String accountHolderName;
	public double amount;
	public String activity;
	public String status;

	public EndOfDayReport(String accountNumber, String accountHolderName, double amount, String activity, String status) {
		this.accountNumber = accountNumber;
		this.accountHolderName = accountHolderName;
		this.amount = amount;
		this.activity = activity;
		this.status = status;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public double getAmount() {
		return amount;
	}

	public String getActivity() {
		return activity;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void display() {
		System.out.printf("| %-21s | %-17s | %-17.2f | %-17s | %-10s|\n", accountNumber, accountHolderName, amount, activity, status);
	}
}

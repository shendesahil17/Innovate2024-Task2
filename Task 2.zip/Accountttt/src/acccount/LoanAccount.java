package acccount;

import java.util.Date;

public class LoanAccount extends Accountt {

	public double loanAmount;
	public Date loanDate;
	public float rateOfInterest;

	public LoanAccount(String accountNumber, String accountHolderName, double balance, String accountType,
			double loanAmount, float rateOfInterest) {
		super(accountNumber, accountHolderName, balance, accountType);
		// this.setLoanAmount(loanAmount);
		this.rateOfInterest = rateOfInterest;
		// setLoanDate(new Date());

		this.loanAmount = loanAmount;
		this.loanDate = new Date();
	}

	@Override
	public void deposit(double amount) {
		super.deposit(amount);
	}

	@Override
	public void withdraw(double amount) {
		// super.withdraw(amount);
		System.out.println("You cannot withdraw money from a loan account");
	}

	@Override
	public double interestRate() {
		// return rateOfInterest;
		double interestAmount = balance * rateOfInterest / 100;
		balance -= interestAmount;
		System.out.println("Calculated interest of " + interestAmount + " for loan account " + accountNumber);
		return rateOfInterest;
	}

	public double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}

	public Date getLoanDate() {
		return loanDate;
	}

	public void setLoanDate(Date loanDate) {
		this.loanDate = loanDate;
	}
}
